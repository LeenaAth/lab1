/*:
## Exercise - Create Functions

 Write a function called `introduceMyself` that prints a brief introduction of yourself. Call the function and observe the printout.
 */
func introduceMyself() {
    print("I'm Guillermo. Nice to meet you.")
}

introduceMyself()


/*:
page 1 of 6  |  [Next: App Exercise - A Functioning App](@next)
 */
import Foundation

func magicEightBall() {
    let randomNum = arc4random_uniform(UInt32(5))
    switch randomNum {
    case 0:
        print("This is a 0.")
    case 1:
        print("This is a 1.")
    case 2:
        print("This is a 2.")
    case 3:
        print("This is a 3.")
    case 4:
        print("This is a 4.")
    default:
        fatalError()
    }
}

magicEightBall()
magicEightBall()
magicEightBall()
